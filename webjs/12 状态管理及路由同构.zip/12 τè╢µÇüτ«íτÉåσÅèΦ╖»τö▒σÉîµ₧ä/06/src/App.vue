<template>
    <div>
        this is App.vue
        <router-link to="/">root</router-link>
        <router-link to="/about">about</router-link>
        <router-view></router-view>
    </div>
</template>