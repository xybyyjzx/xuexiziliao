<template>
    <div>about {{$store.state.timestamp}}</div>
</template>