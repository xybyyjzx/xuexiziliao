<template>
    <div>Home {{$store.state.timestamp}}</div>
</template>