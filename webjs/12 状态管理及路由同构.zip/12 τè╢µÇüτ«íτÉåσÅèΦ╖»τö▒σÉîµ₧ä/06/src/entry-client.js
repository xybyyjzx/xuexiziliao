import {createApp} from './index'

const {vm} = createApp()

vm.$mount('#app')