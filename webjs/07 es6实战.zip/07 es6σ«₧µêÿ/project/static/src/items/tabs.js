import Component from './component';

export default class extends Component {
    
    constructor(props) {
        super(props);
    }
    
    render() {
        return `<div>我是tabs模板</div>`;
    }
}