import MultiplePic from './multiple-pic';
import SinglePic from './single-pic';
import Tabs from './tabs';

export {
    MultiplePic,
    SinglePic,
    Tabs
};